﻿using System;
using System.Collections.Generic;
using Tekla.Structures.Model;
using Tekla.Structures.Geometry3d;
using Win = System.Windows;
using System.Windows.Media.Media3D;

namespace PgtLiftingHole
{
    public class PgtLiftingHoleEngine
    {
        public AssemblyType AssemblyType { get; set; } = Defaultvalues.AssemblyType;
        public double HoleDia { get; set; } = Defaultvalues.HoleDia;
        public double Gage { get; set; } = Defaultvalues.Gage;
        public double B2B { get; set; } = Defaultvalues.B2B;
        public string Name { get; set; } = Defaultvalues.Name;

        public Assembly Assembly { get; }
        public Beam MainPart { get => (Assembly.GetMainPart() as Beam).Name.Equals(Name) ? (Assembly.GetMainPart() as Beam) : null; }
        public WorkPlaneHandler WorkPlaneHandler { get => new Model().GetWorkPlaneHandler(); }

        public static PgtLiftingHoleDefaultvalues _defaultValues;

        public static PgtLiftingHoleDefaultvalues Defaultvalues
        {
            get
            {
                if (_defaultValues == null)
                {
                    _defaultValues = new PgtLiftingHoleDefaultvalues();
                }
                return _defaultValues;
            }
        }

        private int myVar;

        public int MyProperty
        {
            get { return myVar; }
            set { myVar = value; }
        }



        public PgtLiftingHoleEngine(PgtLiftingHoleStructuresData data, Assembly assembly)
        {
            SetData(data);
            Assembly = assembly;
        }

        private void SetData(PgtLiftingHoleStructuresData data)
        {
            if (Enum.IsDefined(typeof(AssemblyType), data.AssemblyType))
                AssemblyType = (AssemblyType)data.AssemblyType;

            if (data.HoleDia != int.MinValue)
                HoleDia = data.HoleDia;

            if (data.Gage != int.MinValue)
                Gage = data.Gage;

            if (data.B2B != int.MinValue)
                B2B = data.B2B;

            if (data.Name != string.Empty)
                B2B = data.B2B;
        }

        public bool Insert()
        {

            WorkPlaneHandler.SetCurrentTransformationPlane(new TransformationPlane());
            var originalTP = WorkPlaneHandler.GetCurrentTransformationPlane();

            // TOD: Handle long beam condition

            // TOD: Handle Short beam condition

            try
            {
                List<ModelObject> modelObjects = new List<ModelObject>();
                if (MainPart != null)
                {

                    Point COG = GetAssemblyCOG(Assembly);

                    Point originForCs = FindOutOrigin(COG);

                    CoordinateSystem rotatedCs = SetCoordinateSystem(originForCs);

                    new CoordinateSystem().DrawCoordinateSystem();


                    var holes = InsertLiftingHoles(rotatedCs);
                    modelObjects.AddRange(holes);
                }
                else
                {
                    Win.MessageBox.Show($"The beam name is not matching with provided beam name {Name}");
                }
                return modelObjects.Count > 0;
            }
            catch (Exception e)
            {

                throw;
            }

            finally
            {
                WorkPlaneHandler.SetCurrentTransformationPlane(originalTP);
            }
        }

        private Point GetAssemblyCOG(Assembly assembly)
        {
            if (!(assembly is null))
            {
                double X = 0;
                double Y = 0;
                double Z = 0;

                var xResult = assembly.GetReportProperty("COG_X", ref X);
                var yResult = assembly.GetReportProperty("COG_Y", ref Y);
                var zResult = assembly.GetReportProperty("COG_Z", ref Z);

                if (xResult && yResult && zResult)
                {
                    ControlPoint controlPoint = new ControlPoint(new Point(X, Y, Z));
                    controlPoint.Insert();
                    controlPoint.Select();
                    var point = controlPoint.Point;
                    controlPoint.Delete();
                    return new Point(point);
                }
            }
            return null;
        }

        private Point FindOutOrigin(Point point)
        {
            Point origin = new Point();

            GeometricPlane beamTransversePlane = new GeometricPlane(point, MainPart.GetCoordinateSystem().AxisX);

            var temp = Projection.PointToPlane(MainPart.StartPoint, beamTransversePlane);

            origin = Projection.PointToPlane(temp, new GeometricPlane(MainPart.GetCoordinateSystem()));
            return origin;
        }

        private CoordinateSystem SetCoordinateSystem(Point point)

        {
            CoordinateSystem cs = new CoordinateSystem();

            cs = new CoordinateSystem()
            {
                AxisX = MainPart.GetCoordinateSystem().AxisX.GetNormal(),
                AxisY = MainPart.GetCoordinateSystem().AxisY.Cross(MainPart.GetCoordinateSystem().AxisX).GetNormal(),
                Origin = point
            };


            double angleInRadians = Math.PI / 4; // 45 degrees in radians
            var rotatedCs = RotateCoordinateSystem(cs, cs.Origin, new Vector3D(cs.GetAxisZ().X, cs.GetAxisZ().Y, cs.GetAxisZ().Z), angleInRadians);
            bool isEdgeDitanceOkay = false; /*CheckEdgeDitance();*/

            if (!isEdgeDitanceOkay)
            {
                // Rotate the coordinate system by 45 degrees counter-clockwise
                //double angleInRadians = Math.PI / 4; // 45 degrees in radians
                cs = RotateCoordinateSystem(cs, cs.Origin, new Vector3D(cs.GetAxisZ().X, cs.GetAxisZ().Y, cs.GetAxisZ().Z), angleInRadians);
            }

            WorkPlaneHandler.SetCurrentTransformationPlane(new TransformationPlane(cs));

            return rotatedCs;
        }


        private CoordinateSystem RotateCoordinateSystem(CoordinateSystem coordinateSystem, Point origin, Vector3D axis, double angle)
        {

            Matrix3D rotationMatrix = new Matrix3D();
            rotationMatrix.Rotate(new Quaternion(axis, angle * (180.0 / Math.PI)));
            var axisX = rotationMatrix.Transform(new Point3D(coordinateSystem.AxisX.X, coordinateSystem.AxisX.Y, coordinateSystem.AxisX.Z));
            var axisY = rotationMatrix.Transform(new Point3D(coordinateSystem.AxisY.X, coordinateSystem.AxisY.Y, coordinateSystem.AxisY.Z));

            coordinateSystem.AxisX = new Vector(axisX.X, axisX.Y, axisX.Z);
            coordinateSystem.AxisY = new Vector(axisY.X, axisY.Y, axisY.Z);
            coordinateSystem.Origin = origin;


            return coordinateSystem;
        }

        private bool CheckEdgeDitance()
        {
            double mainPartWidth = 0.0;
            MainPart.GetReportProperty("WIDTH", ref mainPartWidth);
            return true;
        }

        private List<BoltArray> InsertLiftingHoles(CoordinateSystem rotatedCs)
        {
            List<BoltArray> holes = InsertLiftingHole(AssemblyType, rotatedCs);


            return holes;


        }

        private List<BoltArray> InsertLiftingHole(AssemblyType assemblyType, CoordinateSystem rotatedCs)
        {
            List<BoltArray> holes = new List<BoltArray>();
            switch (assemblyType)
            {
                case AssemblyType.ShortBeam:
                    var hole = PrepareHoleConfiguration(assemblyType, 1, rotatedCs);
                    if (hole != null)
                        holes.Add(hole);
                    break;
                case AssemblyType.LongBeam:
                    var hole1 = PrepareHoleConfiguration(assemblyType, -1, rotatedCs);
                    if (hole1 != null)
                        holes.Add(hole1);

                    var hole2 = PrepareHoleConfiguration(assemblyType, 1, rotatedCs);
                    if (hole2 != null)
                        holes.Add(hole2);
                    break;
                default:
                    break;
            }

            if (holes.Count == 1 || holes.Count == 2)
                holes.ForEach(x => x.Insert());
            return holes;

        }

        private BoltArray PrepareHoleConfiguration(AssemblyType assemblyType, int directionFactor, CoordinateSystem rotatedCs)
        {
            var currentTp = WorkPlaneHandler.GetCurrentTransformationPlane();
            BoltArray boltArray = new BoltArray();

            boltArray.PartToBeBolted = MainPart;
            boltArray.PartToBoltTo = MainPart;
            switch (assemblyType)
            {
                case AssemblyType.ShortBeam:
                    boltArray.FirstPosition = new Point();
                    break;
                case AssemblyType.LongBeam:
                    boltArray.FirstPosition = new Point(B2B * 0.5 * directionFactor, 0, 0);
                    break;
                default:
                    break;
            }

            try
            {

                WorkPlaneHandler.SetCurrentTransformationPlane(new TransformationPlane(rotatedCs));

                boltArray.AddBoltDistX(0);
                boltArray.AddBoltDistY(Gage);
                boltArray.SecondPosition = boltArray.FirstPosition + new Vector(1, 0, 0) * directionFactor * 100;

                boltArray.BoltSize = Defaultvalues.HoleDia;
                boltArray.Tolerance = HoleDia - boltArray.BoltSize;
                boltArray.BoltStandard = Defaultvalues.BoltStandard;
                boltArray.BoltType = BoltGroup.BoltTypeEnum.BOLT_TYPE_WORKSHOP;
                boltArray.CutLength = 105;

                boltArray.Length = 100;
                boltArray.ExtraLength = 15;
                boltArray.ThreadInMaterial = BoltGroup.BoltThreadInMaterialEnum.THREAD_IN_MATERIAL_NO;

                boltArray.Position.Depth = Position.DepthEnum.MIDDLE;
                boltArray.Position.Plane = Position.PlaneEnum.MIDDLE;
                boltArray.Position.Rotation = Position.RotationEnum.FRONT;

                boltArray.Bolt = false;
                boltArray.Washer1 = false;
                boltArray.Washer2 = false;
                boltArray.Washer3 = false;
                boltArray.Nut1 = false;
                boltArray.Nut2 = false;

                boltArray.Hole1 = false;
                boltArray.Hole2 = false;
                boltArray.Hole3 = false;
                boltArray.Hole4 = false;
                boltArray.Hole5 = false;

                boltArray.EndPointOffset.Dy = 0;
                boltArray.StartPointOffset.Dy = 0;
                boltArray.Insert();

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (true)
                {
                    boltArray.Select();
                    WorkPlaneHandler.SetCurrentTransformationPlane(currentTp);
                    boltArray.Select();
                }

            }
            return boltArray;
        }
    }
}
