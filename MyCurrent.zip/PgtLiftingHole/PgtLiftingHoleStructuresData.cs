﻿using Tekla.Structures.Plugins;

namespace PgtLiftingHole
{
    public class PgtLiftingHoleStructuresData
    {
        #region Fields
        [StructuresField("AssemblyType")]
        public int AssemblyType;

        [StructuresField("HoleDia")]
        public double HoleDia;

        [StructuresField("Gage")]
        public double Gage;

        [StructuresField("B2B")]
        public double B2B;       
        
        [StructuresField("Name")]
        public string Name;
        #endregion
    }
}
