﻿using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using Tekla.Structures.Dialog;
using TD = Tekla.Structures.Datatype;

namespace PgtLiftingHole
{
    /// <summary>
    /// Data logic for MainWindow
    /// </summary>
    public class PgtLiftingHoleViewModel : INotifyPropertyChanged
    {
        #region Fields
        private AssemblyType assemblyType = AssemblyType.ShortBeam;
        private TD.Distance holeDia;
        private TD.Distance gage;
        private TD.Distance b2b;
        private string name;

        #endregion
        public PgtLiftingHoleViewModel()
        {
            _enumIntegerConverterProvider = TypeDescriptor.AddAttributes(typeof(TD.Integer), new TypeConverterAttribute(typeof(EnumIntegerConverter)));
        }


        #region Properties
        [StructuresDialog(nameof(AssemblyType), typeof(TD.Integer))]
        public AssemblyType AssemblyType
        {
            get { return assemblyType; }
            set { assemblyType = value; OnPropertyChanged(); }
        }

        [StructuresDialog(nameof(HoleDia), typeof(TD.Distance))]
        public TD.Distance HoleDia
        {
            get { return holeDia; }
            set { holeDia = value; OnPropertyChanged(); }
        }

        [StructuresDialog(nameof(Gage), typeof(TD.Distance))]
        public TD.Distance Gage
        {
            get { return gage; }
            set { gage = value; OnPropertyChanged(); }
        }

        [StructuresDialog(nameof(B2B), typeof(TD.Distance))]
        public TD.Distance B2B
        {
            get { return b2b; }
            set { b2b = value; OnPropertyChanged(); }
        }

        [StructuresDialog(nameof(Name), typeof(TD.String))]
        public string Name
        {
            get { return name; }
            set { name = value; OnPropertyChanged(); }
        }

        #endregion

        public event PropertyChangedEventHandler PropertyChanged;
        private readonly TypeDescriptionProvider _enumIntegerConverterProvider;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }
}
