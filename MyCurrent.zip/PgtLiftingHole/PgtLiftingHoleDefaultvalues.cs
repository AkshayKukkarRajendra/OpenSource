﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgtLiftingHole
{
    public class PgtLiftingHoleDefaultvalues
    {
        public AssemblyType AssemblyType { get; set; } = AssemblyType.ShortBeam;
        public double HoleDia { get; set; } = 8.00;
        public double Gage { get; set; } = 88.9;
        public double B2B { get; set; } = 609.6;
        public string Name { get; set; } = "BEAM";
        public string BoltStandard { get; set; } = "8.8CSK";
    }
}
