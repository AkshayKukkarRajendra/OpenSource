﻿using System;
using System.ComponentModel;

namespace PgtLiftingHole
{
    public static class TypeExtension
    {
        /// <summary>
        /// Return the default value based on the DefaultValueAttribute setting on the type.
        /// </summary>
        /// <param name="type">The type to retrieve the DefaultValue for.</param>
          public static bool IsObsolete(this object value)
        {
            bool isObsolete = false;
            var fi = value.GetType().GetField(value.ToString());
            if (fi != null)
            {
                var attributes = (ObsoleteAttribute[])fi.GetCustomAttributes(typeof(ObsoleteAttribute), false);
                isObsolete = attributes.Length > 0;
            }
            return isObsolete;
        }
        // <returns>The default value; null if the type doesn't have a DefaultValueAttribute attribute.</returns>
        public static object GetDefaultValue(this Type type)
        {
            object value = null;
            if (type != null)
            {
                var attributes = (DefaultValueAttribute[])type.GetCustomAttributes(typeof(DefaultValueAttribute), false);
                if (attributes.Length > 0)
                    value = attributes[0].Value;
            }
            return value;
        }
        /// <summary>
        /// Return the default value based on the DefaultValueAttribute setting on the type and if not set then 
        /// return the default(T) value.
        /// </summary>
        /// <typeparam name="T">The type</typeparam>
        /// <returns>The DefaultValueAttribute setting or if not set then default(T).</returns>
        public static T GetDefaultValue<T>()
        {
            return (T)(typeof(T).GetDefaultValue() ?? default(T));
        }
    }
}
