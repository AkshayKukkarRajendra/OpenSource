﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;

namespace PgtLiftingHole
{
    public class FilteredEnumValuesExtension : MarkupExtension
    {
        private readonly Type _enumType;

        public FilteredEnumValuesExtension(Type enumType)
        {
            if (enumType == null || !enumType.IsEnum)
            {
                throw new ArgumentException("The provided type must be an enum type.");
            }

            _enumType = enumType;
        }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return Enum.GetValues(_enumType)
                .Cast<Enum>()
                .Where(e => !string.IsNullOrWhiteSpace(GetEnumDescription(e)));
        }

        private string GetEnumDescription(Enum value)
        {
            var fieldInfo = value.GetType().GetField(value.ToString());
            var descriptionAttribute = (DescriptionAttribute)Attribute.GetCustomAttribute(fieldInfo, typeof(DescriptionAttribute));
            return descriptionAttribute?.Description ?? value.ToString();
        }
    }
}
