﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tekla.Structures.Model;
using Tekla.Structures.Model.UI;
using Tekla.Structures.Geometry3d;

namespace PgtLiftingHole
{
    public static class GraphicsDrawerExtension
    {
        static GraphicsDrawer gd = new GraphicsDrawer();
        public static Color Red { get; set; } = new Color(1, 0, 0);
        public static Color Green { get; set; } = new Color(0, 1, 0);
        public static Color Blue { get; set; } = new Color(0, 0, 1);
        public static Color Black { get; set; } = new Color(0, 0, 0);
        public static bool DrawCoordinateSystem(this CoordinateSystem coordinateSystem)
        {
            var origin = coordinateSystem.Origin;

            Point axisX_Line_End_Point = origin + coordinateSystem.AxisX.GetNormal() * 100;
            Point axisY_Line_End_Point = origin + coordinateSystem.AxisY.GetNormal() * 100;
            Point axisZ_Line_End_Point = origin + coordinateSystem.GetAxisZ().GetNormal() * 100;

            gd.DrawText(origin, "Org", Black);
            gd.DrawText(axisX_Line_End_Point, "X", Red);
            gd.DrawText(axisY_Line_End_Point, "Y", Green);
            gd.DrawText(axisZ_Line_End_Point, "Z", Blue);

            gd.DrawLineSegment(new LineSegment(origin, axisX_Line_End_Point), Red);
            gd.DrawLineSegment(new LineSegment(origin, axisY_Line_End_Point), Green);
            gd.DrawLineSegment(new LineSegment(origin, axisZ_Line_End_Point), Blue);

            return true;
        }

        public static Vector GetAxisZ(this CoordinateSystem coordinateSystem)
        {
            return coordinateSystem.AxisX.Cross(coordinateSystem.AxisY).GetNormal();
        }
    }
}
