﻿using System;
using System.ComponentModel;
using System.Globalization;
using TSD = Tekla.Structures.Datatype; 

namespace PgtLiftingHole
{
    public class EnumIntegerConverter : TSD.IntegerConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            if (sourceType.BaseType == typeof(Enum))
                return true;
            return base.CanConvertFrom(context, sourceType);
        }
        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            if (destinationType.BaseType == typeof(Enum))
                return true;
            return base.CanConvertTo(context, destinationType);
        }
        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            object returnValue = null;
            if (destinationType.BaseType == typeof(Enum))
            {
                int intvalue = ((TSD.Integer)value).Value;
                if (Enum.IsDefined(destinationType, intvalue))
                {
                    returnValue = Enum.ToObject(destinationType, intvalue);
                }
                else if (intvalue == int.MinValue)
                {
                    returnValue = destinationType.GetDefaultValue();
                    // If returnValue is null then return the first enum value that isn't marked as obsolete.
                    var enumEnum = Enum.GetValues(destinationType).GetEnumerator();
                    while ((returnValue == null) && enumEnum.MoveNext())
                    {
                        if (!enumEnum.Current.IsObsolete())
                            returnValue = enumEnum.Current;
                    }
                }
                if (returnValue == null)
                    throw new ArgumentOutOfRangeException($"{value} is out of range for enum {destinationType.Name}");
            }
            else
            {
                returnValue = base.ConvertTo(context, culture, value, destinationType);
            }
            return returnValue;
        }
        
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            if (value is Enum)
                return new TSD.Integer((int)value);
            return base.ConvertFrom(context, culture, value);
        } 
    }
}
