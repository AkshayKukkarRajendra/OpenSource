﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PgtLiftingHole
{
    public class EnumDescriptionTypeConverter : EnumConverter
    {
        public EnumDescriptionTypeConverter(Type type)
            : base(type)
        {
        }
        public override object ConvertTo(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value, Type destinationType)
        {
            object returnValue;
            if (destinationType == typeof(string))
            {
                if (value == null)
                    returnValue = string.Empty;
                else
                    returnValue = Description(value) ?? ToStringFriendly((Enum)value, true, " ", " ");
            }
            else
            {
                returnValue = base.ConvertTo(context, culture, value, destinationType);
            }
            return returnValue;
        }
        public static string ToStringFriendly(Enum e, bool seperateNumbersFromLetters, string underscoreReplacement, string doubleUnderscoreReplacement)
        {
            string s = e.ToString();

            // enforce a charset: letters, numbers, and underscores
            s = Regex.Replace(s, "[^A-Za-z0-9_]", "");

            // separate letters from numbers
            if (seperateNumbersFromLetters)
                s = Regex.Replace(s, "([0-9])([a-zA-Z])", "$1 $2");

            // space lowercases before uppercase (word boundary)
            s = Regex.Replace(s, "([a-z])([A-Z])", "$1 $2");

            // see that the nice pretty capitalized words are spaced left
            s = Regex.Replace(s, "(?!^)([^ _])([A-Z][a-z]+)", "$1 $2");

            // replace double underscores
            s = Regex.Replace(s, "__", doubleUnderscoreReplacement);

            // finally replace single underscores
            s = Regex.Replace(s, "_", underscoreReplacement);

            return s;
        }

        public static string Description( object value)
        {
            string description = null;
            var fi = value.GetType().GetField(value.ToString());
            if (fi != null)
            {
                var attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);
                if (attributes.Length > 0)
                    description = attributes[0].Description;
            }
            return description;
        }
    }
}
