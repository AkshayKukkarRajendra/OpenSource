﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgtLiftingHole
{
    [DefaultValue(ShortBeam)]
    [TypeConverter(typeof(EnumDescriptionTypeConverter))]
    public enum AssemblyType
    {
        [Description("Short Assembly")]
        ShortBeam,

        [Description("Long Assembly")]
        LongBeam

    }
}
