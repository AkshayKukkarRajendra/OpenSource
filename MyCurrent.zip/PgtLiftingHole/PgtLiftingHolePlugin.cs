using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;
using Tekla.Structures;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using Tekla.Structures.Model.Operations;
using Tekla.Structures.Model.UI;
using Tekla.Structures.Plugins;

namespace PgtLiftingHole
{

    [Plugin("PgtLiftingHole")]
    [PluginUserInterface("PgtLiftingHole.PgtLiftingHole")]
    public class PgtLiftingHolePlugin : PluginBase
    {
        #region Fields
        private Model _Model;
        private PgtLiftingHoleStructuresData _Data;
        #endregion

        #region Properties
        private Model Model
        {
            get { return this._Model; }
            set { this._Model = value; }
        }

        private PgtLiftingHoleStructuresData Data
        {
            get { return this._Data; }
            set { this._Data = value; }
        }
        #endregion

        #region Constructor
        public PgtLiftingHolePlugin(PgtLiftingHoleStructuresData data)
        {
            Model = new Model();
            Data = data;
        }
        #endregion

        #region Overrides
        public override List<InputDefinition> DefineInput()
        {

            List<InputDefinition> inputs = new List<InputDefinition>();
            Picker Picker = new Picker();
            var assembly = Picker.PickObject(Picker.PickObjectEnum.PICK_ONE_OBJECT, "pick assembly") as Assembly;

            inputs.Add(new InputDefinition(assembly.Identifier));

            return inputs;
        }

        public override bool Run(List<InputDefinition> input)
        {
            try
            {
                if (input.Count < 0)
                    throw new Exception($"There must be one input but only {input.Count} were provided.");

                var assemblyInput = input[0];
                if (assemblyInput.GetInputType() != InputDefinition.InputTypeEnum.INPUT_ONE_OBJECT)
                    throw new Exception($"The first input must be a ModelObject but {assemblyInput.GetInputType()} was provided.");

                var assembly = Model.SelectModelObject(assemblyInput.GetInput() as Identifier) as Assembly;

                PgtLiftingHoleEngine engine = new PgtLiftingHoleEngine(Data, assembly);
                return engine.Insert();

            }
            catch (Exception Exc)
            {
                MessageBox.Show(Exc.ToString());
            }

            return true;
        }
        #endregion


    }
}
